import express, { Request, Response } from "express";
import bodyParser from "body-parser";
import { createMedia } from "./pipeline/MediaCreator";

const app = express();
app.use(bodyParser.json());

// порт обязательно приводим к числу
const PORT: number = parseInt(process.env.PORT || "4123", 10);

// =====================
// Health check
// =====================
app.get("/health", (_req: Request, res: Response) => {
  res.json({ status: "ok" });
});

// =====================
// REST API endpoint
// =====================
app.post("/api/media-video", async (req: Request, res: Response) => {
  try {
    const { files, music } = req.body;

    if (!files || !music) {
      return res.status(400).json({ error: "Missing files or music" });
    }

    const output = "final.mp4";
    createMedia(files, music, output);

    res.json({ video: output });
  } catch (err) {
    console.error("Ошибка в /api/media-video:", err);
    res.status(500).json({ error: "Failed to create video" });
  }
});

// =====================
// MCP endpoints
// =====================
app.get("/mcp/sse", (_req: Request, res: Response) => {
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
  });
  res.flushHeaders();

  const tools = [
    {
      name: "media-video",
      description: "Собрать видео из фото/видео/музыки",
      inputSchema: {
        type: "object",
        properties: {
          files: { type: "array", items: { type: "string" } },
          music: { type: "string" },
        },
        required: ["files", "music"],
      },
      outputSchema: {
        type: "object",
        properties: {
          video: { type: "string" },
        },
      },
    },
  ];

  res.write(`data: ${JSON.stringify({ type: "tools", data: tools })}\n\n`);
});

app.post("/mcp/messages", async (req: Request, res: Response) => {
  const body = req.body;

  if (body.type === "callTool" && body.toolName === "media-video") {
    const { files, music } = body.params;
    const output = "final.mp4";

    try {
      createMedia(files, music, output);
      return res.json({ video: output });
    } catch (err) {
      console.error("Ошибка при вызове MCP:", err);
      return res.status(500).json({ error: "Ошибка при создании видео" });
    }
  }

  res.status(400).json({ error: "Invalid MCP request" });
});

// =====================
// Start server
// =====================
app.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ media-video-maker with MCP listening on port ${PORT}`);
});
