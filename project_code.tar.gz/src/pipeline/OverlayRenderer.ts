interface OverlayText {
  text: string;
  start: number;
  end: number;
  x: string;
  y: string;
  fontSize?: number;
  color?: string;
  borderColor?: string;
}

interface OverlayShape {
  type: "circle" | "arrow";
  start: number;
  end: number;
  x: number;
  y: number;
  r?: number;
  x2?: number;
  y2?: number;
  color?: string;
  thickness?: number;
}

export function buildOverlayFilters(texts: OverlayText[], shapes: OverlayShape[]): string {
  const filters: string[] = [];

  for (const t of texts) {
    filters.push(
      `drawtext=text='${t.text}':fontcolor=${t.color || "white"}:fontsize=${t.fontSize || 48}` +
      `:bordercolor=${t.borderColor || "black"}:borderw=3:x=${t.x}:y=${t.y}:enable='between(t,${t.start},${t.end})'`
    );
  }

  for (const s of shapes) {
    if (s.type === "circle") {
      filters.push(
        `drawcircle=x=${s.x}:y=${s.y}:r=${s.r || 60}:color=${s.color || "red"}:thickness=${s.thickness || 5}:enable='between(t,${s.start},${s.end})'`
      );
    }
    if (s.type === "arrow") {
      filters.push(
        `drawline=x1=${s.x}:y1=${s.y}:x2=${s.x2}:y2=${s.y2}:color=${s.color || "red"}:thickness=${s.thickness || 5}:enable='between(t,${s.start},${s.end})'`
      );
    }
  }

  return filters.join(",");
}
