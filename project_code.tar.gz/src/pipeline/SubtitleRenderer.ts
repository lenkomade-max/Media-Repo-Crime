import fs from "fs";
import path from "path";

interface SubtitleWord {
  text: string;
  start: number;
  end: number;
  color?: string;
}

interface SubtitleLine {
  words: SubtitleWord[];
}

export function renderSubtitles(subs: SubtitleLine[], outputPath: string) {
  const assFile = path.join(outputPath, "subs.ass");

  let assContent = `
[Script Info]
Title: Generated Subs
ScriptType: v4.00+
Collisions: Normal
PlayResX: 1280
PlayResY: 720
Timer: 100.0000

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,Arial,42,&H00FFFFFF,&H0000FFFF,&H00000000,&H64000000,-1,0,0,0,100,100,0,0,1,3,0,2,30,30,30,1

[Events]
Format: Layer, Start, End, Style, Text
`;

  for (const line of subs) {
    for (const w of line.words) {
      const start = new Date(w.start * 1000).toISOString().substr(11, 12).replace(".", ",");
      const end = new Date(w.end * 1000).toISOString().substr(11, 12).replace(".", ",");
      const color = w.color || "&H00FFFFFF";
      assContent += `Dialogue: 0,${start},${end},Default,,0,0,0,,{\\c${color}}${w.text}\n`;
    }
  }

  fs.writeFileSync(assFile, assContent);
  return assFile;
}
