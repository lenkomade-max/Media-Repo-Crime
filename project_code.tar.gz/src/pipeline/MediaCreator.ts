import { execSync } from "child_process";
import fs from "fs";
import path from "path";

interface SubtitleStyle {
  color?: string;
  outline?: string;
  font?: string;
}

interface Overlay {
  topText?: string;
  bottomText?: string;
  circle?: boolean;
  arrow?: boolean;
}

export function createMedia(
  files: string[],
  music: string,
  output: string,
  options?: {
    script?: string;
    subtitles?: { enabled: boolean; style?: SubtitleStyle };
    voiceover?: { enabled: boolean; engine: "openai" | "google"; voice?: string };
    overlay?: Overlay;
  }
) {
  const inputDir = "/app/data";
  const outputDir = "/app/output";
  const tmpDir = "/app/tmp";

  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

  const inputFiles = files.map((f) => path.join(inputDir, f));
  const outputFile = path.join(outputDir, output);
  const musicFile = path.join(inputDir, music);

  let cmd: string;

  // --- 1. Фото / Видео
  const ext = path.extname(inputFiles[0]).toLowerCase();
  if (ext === ".jpg" || ext === ".jpeg" || ext === ".png") {
    // Первые кадры 1–1.5с, потом 2–3с
    cmd = `ffmpeg -y -i ${inputDir}/photo1.jpg -i ${inputDir}/photo2.jpg -i ${inputDir}/photo3.jpg -filter_complex "`;
    cmd += `[0:v]setpts=PTS-STARTPTS,trim=duration=1.5[slide1];`;
    cmd += `[1:v]setpts=PTS-STARTPTS,trim=duration=1.5[slide2];`;
    cmd += `[2:v]setpts=PTS-STARTPTS,trim=duration=2.5[slide3];`;
    cmd += `[slide1][slide2][slide3]concat=n=3:v=1:a=0[outv]" -map "[outv]" ${tmpDir}/slides.mp4`;
    execSync(cmd);
    cmd = `ffmpeg -y -i ${tmpDir}/slides.mp4 -i ${musicFile}`;
  } else {
    const listFile = path.join(tmpDir, "files.txt");
    fs.writeFileSync(listFile, inputFiles.map((f) => `file '${f}'`).join("\n"));
    cmd = `ffmpeg -y -f concat -safe 0 -i ${listFile} -i ${musicFile}`;
  }

  // --- 2. Озвучка
  let voiceFile = "";
  if (options?.voiceover?.enabled) {
    voiceFile = path.join(tmpDir, "voice.mp3");
    // ⚡ тут ты подключишь OpenAI TTS или Google TTS → и запишешь в voiceFile
    // пока ffmpeg будет ожидать этот файл
    cmd += ` -i ${voiceFile} -filter_complex "[1:a][2:a]amix=inputs=2:duration=longest[a]" -map 0:v -map "[a]"`;
  }

  // --- 3. Субтитры
  let subtitlesFilter = "";
  if (options?.subtitles?.enabled && options.script) {
    const srtFile = path.join(tmpDir, "subs.srt");
    fs.writeFileSync(
      srtFile,
      `1\n00:00:00,000 --> 00:00:05,000\n${options.script}\n\n`
    );
    subtitlesFilter = `subtitles=${srtFile}`;
  }

  // --- 4. Оверлеи
  const draw: string[] = [];
  if (options?.overlay?.topText) {
    draw.push(
      `drawtext=text='${options.overlay.topText}':fontcolor=white:fontsize=48:x=(w-text_w)/2:y=50:box=1:boxcolor=black@0.5`
    );
  }
  if (options?.overlay?.bottomText) {
    draw.push(
      `drawtext=text='${options.overlay.bottomText}':fontcolor=white:fontsize=48:x=(w-text_w)/2:y=h-th-50:box=1:boxcolor=black@0.5`
    );
  }
  if (options?.overlay?.circle) {
    draw.push(
      `drawbox=x=100:y=100:w=150:h=150:color=red@0.0:t=5:enable='between(t,0,5)'`
    );
  }
  if (options?.overlay?.arrow) {
    draw.push(
      `drawtext=text='➡':fontcolor=yellow:fontsize=72:x=200+10*t:y=200:enable='between(t,0,5)'`
    );
  }

  let vf = [];
  if (subtitlesFilter) vf.push(subtitlesFilter);
  if (draw.length) vf.push(draw.join(","));
  if (vf.length) cmd += ` -vf "${vf.join(",")}"`;

  // --- 5. Финал
  cmd += ` -shortest -c:v libx264 -pix_fmt yuv420p -c:a aac ${outputFile}`;

  console.log("▶️ Запускаем команду:", cmd);
  execSync(cmd);
  console.log("✅ Видео готово:", outputFile);
}
